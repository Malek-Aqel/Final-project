package com.example.afinal;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
//import org.json.simple.parser.JSONParser;
//import org.json.simple.parser.ParseException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;

public class rooms extends AppCompatActivity {
    /*
    Image Credit:
    Images in this tutorial are originally made by Konpa (under MIT License)
    Link for download: https://devicons.github.io/devicon/
    License: https://github.com/devicons/devicon/blob/master/LICENSE
     */
    // Declare a RecyclerView object reference
    RecyclerView recyclerView;
    // Declare an adapter
    RecyclerView.Adapter roomAdapter;
    RecyclerView.LayoutManager layoutmanager;
    // Next, prepare your data set. Create two string arrays for program name and program description respectively.
    //String[] roomNameList = {"standerd", "standerdplus", "delux", "deluxplus", "premium", "premiumplus", "suite", "suiteplus"};
    String[] roomNameList;
    String[] roomDescriptionList = {"standerd Description", "standerdplus Description", "delux Description",
            "deluxplus Description", "premium Description",
            "premiumplus Description", "suite Description", "suiteplus Description"};
    // Define an integer array to hold the image recourse ids
    int[] roomImages = {R.drawable.standredplus, R.drawable.delux,
            R.drawable.deluxplus, R.drawable.premium, R.drawable.premiumplus,
            R.drawable.standerd, R.drawable.suite, R.drawable.suiteplus};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rooms);
        // Obtain a handle for the RecyclerView
        recyclerView = findViewById(R.id.rvmain);
        // You may use this setting to improve performance if you know that changes
        // in content do not change the layout size of the RecyclerView
        recyclerView.setHasFixedSize(true);
        // Use a linear layout manager
        layoutmanager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutmanager);


        String roomsAPI = ("http://10.0.2.2/db/rooms.php");


        /*try {
            roomNameList = loadIntoListView(getJSON("http://10.0.2.2/db/rooms.php"));
        } catch (JSONException e) {
            e.printStackTrace();
        }*/


        //Toast.makeText(getApplicationContext(), roomNameList[0], Toast.LENGTH_SHORT).show();

        // Create an instance of ProgramAdapter. Pass context and all the array elements to the constructor
        /*roomAdapter = new roomAdapter(this, sendGetRequest(), roomDescriptionList, roomImages);
        // Finally, attach the adapter with the RecyclerView
        recyclerView.setAdapter(roomAdapter);*/

        sendGetRequest();


    }

    public void Home(View view) {
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
    }

    //this method is actually fetching the json string
    private String getJSON(final String urlWebService) {
        /*
         * As fetching the json string is a network operation
         * And we cannot perform a network operation in main thread
         * so we need an AsyncTask
         * The constrains defined here are
         * Void -> We are not passing anything
         * Void -> Nothing at progress update as well
         * String -> After completion it should return a string and it will be the json string
         * */
        class GetJSON extends AsyncTask<Void, Void, String> {
            String json;

            //this method will be called before execution
            //you can display a progress bar or something
            //so that user can understand that he should wait
            //as network operation may take some time
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }

            //this method will be called after execution
            //so here we are displaying a toast with the json string
            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                Toast.makeText(getApplicationContext(), s, Toast.LENGTH_SHORT).show();
            }

            //in this method we are fetching the json string
            @Override
            protected String doInBackground(Void... voids) {



                try {
                    //creating a URL
                    URL url = new URL(urlWebService);

                    //Opening the URL using HttpURLConnection
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();

                    //StringBuilder object to read the string from the service
                    StringBuilder sb = new StringBuilder();

                    //We will use a buffered reader to read the string from service
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));

                    //A simple string to read values from each line


                    //reading until we don't find null
                    while ((json = bufferedReader.readLine()) != null) {

                        //appending it to string builder
                        sb.append(json + "\n");
                    }

                    //finally returning the read string
                    return sb.toString().trim();
                } catch (Exception e) {
                    return null;
                }

            }
        }

        //creating asynctask object and executing it
        GetJSON getJSON = new GetJSON();
        getJSON.execute();

        return getJSON.json;
    }

    private String[] sendGetRequest() {

        String[] roomNameList1 = new String[8];
        //get working now
        //let's try post and send some data to server
        RequestQueue queue= Volley.newRequestQueue(this);
        String url="http://10.0.2.2/db/rooms.php";
        StringRequest stringRequest=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                //get_response_text.setText("Data : "+response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    ArrayList<String> nn = new ArrayList<>();
                    String[] roomDescriptionList = new String[jsonArray.length()];

                    for(int i = 0 ; i < jsonArray.length() ; i++){

                        JSONObject jsonObj = (JSONObject) jsonArray.get(i);


                        int id = Integer.parseInt(jsonObj.get("id").toString());
                        String name = jsonObj.get("name").toString();
                        String disc = jsonObj.get("disc").toString();
                        int price = Integer.parseInt(jsonObj.get("price").toString());
                        int available = Integer.parseInt(jsonObj.get("available").toString());
                        Date from = new SimpleDateFormat("yyyy-MM-DD").parse(jsonObj.get("fromm").toString());
                        Date too = new SimpleDateFormat("yyyy-MM-DD").parse(jsonObj.get("too").toString());
                        String area = jsonObj.get("area").toString();


                        nn.add(name);



                        room r = new room( id,  name,  disc,  price,  available,  from, too,  area);


                    }


                    for(int i = 0 ; i < nn.size() ; i++){

                        roomNameList1[i] = nn.get(i);
                    }

                    Toast.makeText(getApplicationContext(), roomNameList1[0], Toast.LENGTH_SHORT).show();

                    roomAdapter = new roomAdapter(getApplicationContext(), roomNameList1, roomDescriptionList, roomImages);
                    // Finally, attach the adapter with the RecyclerView
                    recyclerView.setAdapter(roomAdapter);




                }
                catch (Exception e){
                    e.printStackTrace();
                    //get_response_text.setText("Failed to Parse Json");
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //get_response_text.setText("Data : Response Failed");
            }
        });

        queue.add(stringRequest);


        return roomNameList1;
    }





    private String[] loadIntoListView(String json) throws JSONException {







            //String jsonDataString = json;
            //JSONArray jsonArray = new JSONArray(jsonDataString);
      /*  JSONParser jsonParser = new JSONParser();

        JSONObject jsonObject = null;
        try {
            jsonObject = (JSONObject) jsonParser.parse(json);
        } catch (ParseException e) {
            e.printStackTrace();
        }


        JSONArray jsonArray = (JSONArray) jsonObject.get("contact");



            /*String[] rooms = new String[jsonArray.length()];

            for (int i=0; i<jsonArray.length(); ++i) {

                JSONObject itemObj = jsonArray.getJSONObject(i);

                String name = itemObj.getString("name");
                String date = itemObj.getString("date");

                rooms[i]=name;
                //room room = new room(name);


            }*/






                //JSONObject jsonObj = new JSONObject(json);


                /*

                // Getting JSON Array node
                JSONArray rooms = jsonObj.getJSONArray("data");

                String[] roomList = new String[rooms.length()];

                // looping through All Contacts
                for (int i = 0; i < rooms.length(); i++) {
                    JSONObject c = rooms.getJSONObject(i);

                    //String id = c.getString("id");
                    roomList[i] = c.getString("name");
                    /*String email = c.getString("email");
                    String address = c.getString("address");
                    String gender = c.getString("gender");

                    // Phone node is JSON Object
                    JSONObject phone = c.getJSONObject("phone");
                    String mobile = phone.getString("mobile");
                    String home = phone.getString("home");
                    String office = phone.getString("office");

                    // tmp hash map for single contact
                    //HashMap<String, String> contact = new HashMap<>();

                    // adding each child node to HashMap key => value
                    //contact.put("id", id);
                    //contact.put("name", name);
                    //contact.put("email", email);
                    //contact.put("mobile", mobile);

                    // adding contact to contact list
                    //roomList.add(contact);
                }*/

        Toast.makeText(getApplicationContext(), json, Toast.LENGTH_SHORT).show();

        String[] roomss = {"standerd", "standerdplus", "delux", "deluxplus", "premium", "premiumplus", "suite", "suiteplus"};


        return roomss;
    }





    /*private String[] loadIntoListView(String json) throws JSONException {



        String[] rooms = {"standerd", "standerdplus", "delux", "deluxplus", "premium", "premiumplus", "suite", "suiteplus"};



       //creating a json array from the json string
        JSONArray jsonArray = new JSONArray(json);

        //creating a string array for listview
        String[] rooms = new String[jsonArray.length()];

        //looping through all the elements in json array
        for (int i = 0; i < jsonArray.length(); i++) {

            //getting json object from the json array
            JSONObject obj = jsonArray.getJSONObject(i);

            //getting the name from the json object and putting it inside string array
            rooms[i] = obj.getString("name");
        }

        Toast.makeText(getApplicationContext(),rooms[0], Toast.LENGTH_SHORT).show();

        return rooms;
    }*/

}